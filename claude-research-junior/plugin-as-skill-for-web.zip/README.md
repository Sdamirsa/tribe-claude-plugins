# Claude Research Junior — Plugin-as-Skill for Web

This is the **web-compatible bundle** of the `claude-research-junior` plugin, for use with [claude.ai](https://claude.ai) (Claude Chat), which does not support native plugins.

It contains the same 12 skills as the plugin version, repackaged as plain markdown files you can upload to a Claude Project.

## What's inside

```
plugin-as-skill-for-web/
├── README.md                   ← this file
├── PROJECT-INSTRUCTIONS.md     ← paste into the Project's Custom Instructions
└── skills/                     ← upload all of these as Project knowledge
    ├── foundation-scout/
    ├── crystalit/
    ├── crystalit-noter/
    ├── crystalit-ontologist/
    ├── crystalit-labeler/
    ├── crystalit-vizmaker/
    ├── crystalit-writer/
    ├── scope-strategist/
    ├── paper-architect/
    ├── figure-strategist/
    ├── paper-polisher/
    └── panel-discussion/
```

## How to install in Claude Chat

1. Go to [claude.ai](https://claude.ai) → **Projects** → **New project**.
2. Name it something like `Research Junior`.
3. Open `PROJECT-INSTRUCTIONS.md` from this bundle. Copy its full contents and paste them into the project's **Custom Instructions** field.
4. Open the `skills/` folder. Upload every `SKILL.md` file (and any `references/` files) into the project's **Knowledge** section. You can drag the whole folder in — Claude Chat will flatten it.
5. Start a new chat inside the project. Ask things like *"run CrystaLit on my papers"* or *"help me scope my paper"* — Claude will consult the relevant SKILL.md and follow its instructions.

## Limitations vs. the real plugin

- Claude Chat cannot execute scripts, so anything in a skill that runs bash or Python has to be done by you manually and results pasted back.
- Skills will not auto-trigger on keywords as precisely as in Cowork or Claude Code. You may need to name the skill explicitly, e.g., *"use the scope-strategist skill to…"*.
- No progressive disclosure of `references/` files — they're always visible in project knowledge. This uses more context but is otherwise fine.

## Updates

Each release of this bundle matches the corresponding plugin release. If you're on `plugin-as-skill-for-web-v0.1.0-alpha`, it maps to `claude-research-junior-v0.1.0-alpha`.

To update, delete the old Project knowledge and re-upload from the latest bundle.
