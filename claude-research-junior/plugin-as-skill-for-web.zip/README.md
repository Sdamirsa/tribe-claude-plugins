# Claude Research Junior — Plugin-as-Skill for Web

Web-compatible bundle of the `claude-research-junior` plugin, for [claude.ai](https://claude.ai) (Claude Chat), which does not support native plugins.

Contains the same 13 skills as the plugin version (12 research workflow skills + scientific-writing), repackaged as plain markdown you can upload to a Claude Project.

## How to install in Claude Chat

1. Go to [claude.ai](https://claude.ai) → **Projects** → **New project**.
2. Name it something like `Research Junior`.
3. Open `PROJECT-INSTRUCTIONS.md`. Copy its full contents and paste them into the project's **Custom Instructions** field.
4. Drag the entire `skills/` folder into the project's **Knowledge** area.
5. Start a new chat inside the project. Ask things like *"run CrystaLit on my papers"* or *"help me scope my paper"*.

## Limitations vs. the native plugin

Claude Chat cannot execute scripts, so anything in a skill that runs bash or Python must be done manually and pasted back. Skills do not auto-trigger on keywords as precisely as in Cowork or Claude Code — you may need to name the skill explicitly. No progressive disclosure of `references/` files.

## Citations

This bundle uses plain Markdown `[@citekey]` citation syntax. Manage your own bibliography file (BibTeX or CSL JSON) in your project. No external citation skill required.

## Version

This bundle corresponds to `claude-research-junior-v0.1.0-alpha`.
